namespace SharedKernel.Services
{
    /// <summary>
    /// Interfaz para implementar automaticamente la inyecci�n de dependencias de servicios.
    /// </summary>
    public interface IScopedService
    {
    }
}