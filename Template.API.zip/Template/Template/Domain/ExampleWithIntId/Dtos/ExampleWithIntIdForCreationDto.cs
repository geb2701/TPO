namespace Template.Domain.ExampleWithIntId.Dtos;

public sealed record ExampleWithIntIdForCreationDto
{
    public string Name { get; set; }
}