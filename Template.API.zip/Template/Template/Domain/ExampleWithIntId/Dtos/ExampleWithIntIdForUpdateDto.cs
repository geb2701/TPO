namespace Template.Domain.ExampleWithIntId.Dtos;

public sealed record ExampleWithIntIdForUpdateDto
{
    public string Name { get; set; }
}