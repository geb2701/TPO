namespace Template.Domain.ExampleWithIntId.Models;

public sealed record ExampleWithIntIdForUpdate
{
    public string Name { get; set; }
}