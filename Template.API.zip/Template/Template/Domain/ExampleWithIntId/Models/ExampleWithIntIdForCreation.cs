namespace Template.Domain.ExampleWithIntId.Models;

public sealed record ExampleWithIntIdForCreation
{
    public string Name { get; set; }
}