namespace Template.Domain.ExampleWithStringId.Models;

public sealed record ExampleWithStringIdForCreation
{
    public string Code { get; set; }
    public string Name { get; set; }
}