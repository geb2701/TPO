namespace Template.Domain.ExampleWithStringId.Models;

public sealed record ExampleWithStringIdForUpdate
{
    public string Name { get; set; }
}