namespace Template.Domain.ExampleWithStringId.Dtos;

public sealed record ExampleWithStringIdForUpdateDto
{
    public string Name { get; set; }
}