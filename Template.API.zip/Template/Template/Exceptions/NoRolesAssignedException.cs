namespace Template.Exceptions;

public class NoRolesAssignedException : Exception
{
}