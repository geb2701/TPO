namespace Template.Exceptions;

public class ForbiddenAccessException : Exception
{
}